package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private TextView txt_status;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //ON Button
        Button switch_on = findViewById(R.id.on);
        //OFF Button
        Button switch_off = findViewById(R.id.off);
        //Status Button
        Button check = findViewById(R.id.status);
        //Status Text View
        txt_status = findViewById(R.id.bulb_status);

        //On BTN is clicked
        switch_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // set the field1 option as 1
                String url = "https://api.thingspeak.com/update?api_key=6L6I6TUNO8YDNYDB&field1=1";
                set_field1(url,"on!");
            }
        });

        //OFF BTN is clicked
        switch_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //set the field1 option as 0
                String url = "https://api.thingspeak.com/update?api_key=6L6I6TUNO8YDNYDB&field1=0";
                set_field1(url,"off!");
            }
        });

        //bulb_status is clicked
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Getting the data from APi given
                String url = "https://api.thingspeak.com/channels/1304924/feeds.json?api_key=UPMUTEH5T620OWWX&results=2";
                get_field1(url);
            }
        });
    }
    public void set_field1(String url,String condn)
    {
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        make_toast("bulb is "+condn);
                    }}, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                make_toast("Error");
            }
        });
        queue.add(stringRequest);
    }
    public void get_field1(String url)
    {
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray feeds  = obj.getJSONArray("feeds");
                            JSONObject obj2 = feeds.getJSONObject(feeds.length()-1);
                            String field1 = obj2.getString("field1");
                            if (field1.equals("0"))
                            {
                                txt_status.setText("BULB is OFF!");
                            }else
                            {
                                txt_status.setText("BULB is ONN!");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }}, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                make_toast("Error");
            }
        });
        queue.add(stringRequest);
    }
    public void make_toast(String resp)
    {
        Toast.makeText(this,resp,Toast.LENGTH_SHORT).show();
    }

}